package Collections.Inheritance.DiamonProblem;

public interface B {
    default void printA(){
        System.out.println("This is in Parent B");
    }
}
