package Collections.Polymorphism;

public class RuntimePoly {
    void mainHoJian(){
        System.out.println("This is Jian");
    }
}
