package Collections.Abstraction;

public interface Inheritance1 {



    default void kabir(){
        System.out.println("I am annoying");
    }


}
