package Collections.Abstraction;

abstract class AbstractionClass {
    abstract void kabir();

    void mainHooJian(){
        System.out.println("Main hoon sabse takatwar");
    }
}
