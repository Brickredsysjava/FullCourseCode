package Collections.UserDefinedArrayList;

public class Home extends Adress{

    int landline;

    public Home(String current, String permanent, String pankajKiNaniKaGhar, int landline) {
        super(current, permanent, pankajKiNaniKaGhar);
        this.landline = landline;
    }

    public Home(String current, String permanent, String pankajKiNaniKaGhar) {
        super(current, permanent, pankajKiNaniKaGhar);
    }


}
