package Collections.UserDefinedArrayList;

public class Adress {
    String current;

    String Permanent;

    String PankajKiNaniKaGhar;

    public Adress(String current, String permanent, String pankajKiNaniKaGhar) {
        this.current = current;
        this.Permanent = permanent;
        this.PankajKiNaniKaGhar = pankajKiNaniKaGhar;
    }
}
