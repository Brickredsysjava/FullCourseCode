package Collections.Inheritance;

public class Parent {
    public void print(){
        System.out.println("Crawl");
        //return 0;
    }
}
