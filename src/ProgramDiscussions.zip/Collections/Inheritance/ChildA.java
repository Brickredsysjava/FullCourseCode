package Collections.Inheritance;

public class ChildA extends Parent{
    @Override
    public void print() {
        super.print();
        System.out.println("Walk");
        System.out.println("");
    }

    public static void main(String[] args) {

    }
}
