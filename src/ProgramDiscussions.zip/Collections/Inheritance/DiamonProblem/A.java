package Collections.Inheritance.DiamonProblem;

public interface A {
    default void printA(){
        System.out.println("This is in Parent A");
    }
}
