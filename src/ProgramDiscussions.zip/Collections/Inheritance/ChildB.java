package Collections.Inheritance;

public class ChildB extends Parent{
    @Override
    public void print() {
        super.print();
        System.out.println("Run");
    }
}
